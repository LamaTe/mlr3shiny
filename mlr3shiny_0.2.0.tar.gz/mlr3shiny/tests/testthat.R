library(testthat)
library(mlr3shiny)
library(shinytest)

test_check("mlr3shiny")
