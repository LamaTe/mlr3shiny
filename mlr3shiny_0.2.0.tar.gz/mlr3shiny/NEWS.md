# mlr3shiny 0.1.1

* Adding various new algorithm evaluation metrics
* Adding option to change default class for twoclass classifications 
* Updating dependencies and fixing dependency bugs
